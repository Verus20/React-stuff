from rest_framework import serializers
from leads.models import lead

# Lead Serializer
class leadSerializer(serializers.ModelSerializer):
    class Meta:
        model = lead
        fields = "__all__"